/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    '.public/*.{html,js,php}', // Adjust the paths to your project structure
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}